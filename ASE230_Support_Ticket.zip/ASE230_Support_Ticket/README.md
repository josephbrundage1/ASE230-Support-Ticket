# ASE 230 Support Ticket Application

## Run the project

1. Extract this folder into XAMPP's `htdocs` folder.
2. Start Apache in XAMPP.
3. Open `http://localhost/ASE230_Support_Ticket_Simple/` in your browser.

## Files

- `index.php` displays and filters tickets.
- `detail.php` displays a ticket and its status form.
- `create.php` validates and saves new tickets.
- `update-status.php` processes status changes using POST.
- `includes/functions.php` contains functions for loading, saving, searching, and updating tickets.
- `data/tickets.json` stores the tickets.
- `uploads/` stores optional images.

Make sure PHP can write to `data/tickets.json` and the `uploads/` folder.

The implementation uses basic arrays, loops, conditionals, functions, PHP form variables, and `json_encode()` / `json_decode()`.
