1. Searching uses GET because the search terms and filters only retrieve information. Creating a ticket changes server-side data, so it uses POST to submit the new record to the server.

2. HTML validation helps users correct mistakes in the browser, but it can be bypassed by sending a request directly to the server. Server-side validation checks the values before the app saves them, helping to protect data.

3. PHP receives an uploaded file in a temporary location. The app checks the status, size, and actual file type before moving it to the uploads directory with a filename.

4. The same process pattern could be used in EConnect in a few ways. One of the ways is by validating users reservation rquests. Another is to verify that there are enough remaining tickets for desired reservation. In adition it can be used to update the database and return a confirmation or an error.