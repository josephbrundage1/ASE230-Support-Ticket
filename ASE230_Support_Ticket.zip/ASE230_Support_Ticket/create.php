<?php
require_once __DIR__ . '/includes/functions.php';

$values = [
    'name' => '',
    'email' => '',
    'category' => '',
    'description' => ''
];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $values['name'] = trim($_POST['name'] ?? '');
    $values['email'] = trim($_POST['email'] ?? '');
    $values['category'] = trim($_POST['category'] ?? '');
    $values['description'] = trim($_POST['description'] ?? '');

    // Check the form values on the server.
    if ($values['name'] === '') {
        $errors[] = 'Customer name is required.';
    }

    if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    if (!in_array($values['category'], allowedCategories())) {
        $errors[] = 'Choose a valid category.';
    }

    if (strlen($values['description']) < 10) {
        $errors[] = 'Description must be at least 10 characters long.';
    }

    $attachment = null;
    $uploadedFile = '';

    // The image is optional.
    if (isset($_FILES['attachment']) &&
        $_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {

        if ($_FILES['attachment']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'There was a problem uploading the image.';
        } elseif ($_FILES['attachment']['size'] > 5 * 1024 * 1024) {
            $errors[] = 'The image must be 5 MB or smaller.';
        } else {
            // Check the real image type instead of trusting the filename.
            $imageInfo = getimagesize($_FILES['attachment']['tmp_name']);

            if ($imageInfo === false) {
                $errors[] = 'Please upload a valid image.';
            } else {
                $imageTypes = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp'
                ];

                if (!isset($imageTypes[$imageInfo['mime']])) {
                    $errors[] = 'Only JPG, PNG, and WebP images are allowed.';
                } else {
                    // Make a new filename so the original filename is not used.
                    $fileName = uniqid() . '.' . $imageTypes[$imageInfo['mime']];
                    $uploadedFile = UPLOAD_DIR . $fileName;

                    if (move_uploaded_file($_FILES['attachment']['tmp_name'], $uploadedFile)) {
                        $attachment = $fileName;
                    } else {
                        $errors[] = 'The image could not be saved.';
                    }
                }
            }
        }
    }

    if (empty($errors)) {
        $tickets = loadTickets();

        $newTicket = [
            'id' => nextTicketId($tickets),
            'name' => $values['name'],
            'email' => $values['email'],
            'category' => $values['category'],
            'description' => $values['description'],
            'status' => 'Open',
            'attachment' => $attachment
        ];

        $tickets[] = $newTicket;

        if (saveTickets($tickets)) {
            header('Location: detail.php?id=' . $newTicket['id']);
            exit;
        } else {
            // Remove the uploaded image if the ticket could not be saved.
            if ($uploadedFile !== '' && file_exists($uploadedFile)) {
                unlink($uploadedFile);
            }

            $errors[] = 'The ticket could not be saved.';
        }
    } elseif ($uploadedFile !== '' && file_exists($uploadedFile)) {
        unlink($uploadedFile);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Support Ticket</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<main class="container">
    <p><a href="index.php">&larr; Back to tickets</a></p>

    <section class="panel">
        <h1>Create Support Ticket</h1>
        <p>Complete the form below. Important validation must occur on the server.</p>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <strong>Please correct the following:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= e($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="create.php" enctype="multipart/form-data">
            <label for="name">Customer Name</label>
            <input type="text" id="name" name="name" value="<?= e($values['name']) ?>" required>

            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" value="<?= e($values['email']) ?>" required>

            <label for="category">Category</label>
            <select id="category" name="category" required>
                <option value="">Choose a category</option>
                <?php foreach (allowedCategories() as $category): ?>
                    <option value="<?= e($category) ?>" <?= $values['category'] === $category ? 'selected' : '' ?>>
                        <?= e(ucfirst($category)) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="description">Description</label>
            <textarea id="description" name="description" rows="7" required><?= e($values['description']) ?></textarea>

            <label for="attachment">Optional Image (JPG, PNG, or WebP; maximum 5 MB)</label>
            <input type="file" id="attachment" name="attachment" accept="image/jpeg,image/png,image/webp">

            <button type="submit">Submit Ticket</button>
        </form>
    </section>
</main>
</body>
</html>
