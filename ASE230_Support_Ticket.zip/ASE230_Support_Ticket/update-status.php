<?php
require_once __DIR__ . '/includes/functions.php';

// Status changes must use POST.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Please submit the status form.');
}

$id = $_POST['id'] ?? '';
$status = $_POST['status'] ?? '';

// Check the ticket ID and requested status.
if (!is_numeric($id) || (int)$id < 1 || !in_array($status, allowedStatuses())) {
    http_response_code(400);
    exit('Invalid ticket ID or status.');
}

$id = (int)$id;
$tickets = loadTickets();

if (!updateTicketStatus($tickets, $id, $status)) {
    http_response_code(404);
    exit('Ticket not found.');
}

if (!saveTickets($tickets)) {
    http_response_code(500);
    exit('Could not save the ticket.');
}

header('Location: detail.php?id=' . $id);
exit;
