<?php

const DATA_FILE = __DIR__ . '/../data/tickets.json';
const UPLOAD_DIR = __DIR__ . '/../uploads/';

function allowedCategories(): array
{
    return ['technical', 'billing', 'account', 'other'];
}

function allowedStatuses(): array
{
    return ['Open', 'In Progress', 'Resolved'];
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function loadTickets(): array
{
    if (!file_exists(DATA_FILE)) {
        return [];
    }

    $json = file_get_contents(DATA_FILE);
    $tickets = json_decode($json, true);

    if (is_array($tickets)) {
        return $tickets;
    }

    return [];
}

function saveTickets(array $tickets): bool
{
    $json = json_encode($tickets, JSON_PRETTY_PRINT);

    if ($json === false) {
        return false;
    }

    if (file_put_contents(DATA_FILE, $json) === false) {
        return false;
    }

    return true;
}

function findTicketById(array $tickets, int $id): ?array
{
    foreach ($tickets as $ticket) {
        if (isset($ticket['id']) && (int)$ticket['id'] === $id) {
            return $ticket;
        }
    }

    return null;
}

function nextTicketId(array $tickets): int
{
    $highestId = 0;

    foreach ($tickets as $ticket) {
        if (isset($ticket['id']) && $ticket['id'] > $highestId) {
            $highestId = (int)$ticket['id'];
        }
    }

    return $highestId + 1;
}

function filterTickets(
    array $tickets,
    string $query = '',
    string $status = '',
    string $category = ''
): array {
    $filtered = [];

    foreach ($tickets as $ticket) {
        if ($status !== '' && $ticket['status'] !== $status) {
            continue;
        }

        if ($category !== '' && $ticket['category'] !== $category) {
            continue;
        }

        $searchText = strtolower(
            $ticket['name'] . ' ' .
            $ticket['email'] . ' ' .
            $ticket['description']
        );

        if ($query !== '' && strpos($searchText, strtolower($query)) === false) {
            continue;
        }

        $filtered[] = $ticket;
    }

    return $filtered;
}

function updateTicketStatus(array &$tickets, int $id, string $newStatus): bool
{
    if (!in_array($newStatus, allowedStatuses())) {
        return false;
    }

    foreach ($tickets as $key => $ticket) {
        if ((int)$ticket['id'] === $id) {
            $tickets[$key]['status'] = $newStatus;
            return true;
        }
    }

    return false;
}
